import styled from 'styled-components';

export const Wrapper = styled.aside`
  font-family: Arial, Helvetica, sans-serif;
  width: 400px;
  padding: 20px;

 .payCartBtn{
   border:3px solid green;
   text-align:center;
   text-size:5em;
 }
 .CreditCardIcon{
  font-size:2em;
  color:green;
 }
 

`;