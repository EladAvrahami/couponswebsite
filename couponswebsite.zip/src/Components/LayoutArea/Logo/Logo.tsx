import "./Logo.css";

function Logo(): JSX.Element {
    return (
        <div className="Logo">
			
        </div>
    );
}

export default Logo;
