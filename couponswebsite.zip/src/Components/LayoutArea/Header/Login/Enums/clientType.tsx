 enum clientType{

   ADMINISTRATOR="admin",
   COMPANY="company",
   CUSTOMER="customer",
   GUEST="guest"
}
export default clientType;