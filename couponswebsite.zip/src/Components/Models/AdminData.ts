class AdminData{


}

export default AdminData