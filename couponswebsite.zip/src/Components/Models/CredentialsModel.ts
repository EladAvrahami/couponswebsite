class CredentialsModel{
  
    public password: string;
    public email: string; 
    public clientType: string; 
   
}
export default CredentialsModel;