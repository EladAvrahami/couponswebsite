import { EnumType } from "typescript";

class CouponData{
id:number=0;
companyID:number=0;
category:string="";
title:string="";
description:string="";
startDate:string="";
endDate:string="";
amount:number=0;
price:number=0;
image:string="";

}
export default CouponData