import CouponData from "./CouponData";

class CompanyData{
id:number;
name:string;
email:string;
password:string;
coupons:CouponData[];
    
}
export default CompanyData;