class UserModel{
    public email:string;
    public password:string;
    public clientType:string;
    public token?:string;
    public userId:number;
    public name:string;
}
export default UserModel;