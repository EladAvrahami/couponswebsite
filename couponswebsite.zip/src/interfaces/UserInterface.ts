export interface UserInterface {
    clientType: string,
    email: string,
    password: string,
    token: string,
    userId: number
}